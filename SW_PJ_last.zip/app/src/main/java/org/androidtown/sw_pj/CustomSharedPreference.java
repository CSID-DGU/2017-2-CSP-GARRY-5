package org.androidtown.sw_pj;

import android.app.Activity;
import android.content.SharedPreferences;

public class CustomSharedPreference {
    Activity activity;
    SharedPreferences pref;

    CustomSharedPreference(Activity activity) {
        this.activity = activity;
    }

    //문자 저장
    public void savePreference(String key, String value) {
        setsp();
        SharedPreferences.Editor editor = pref.edit();
        editor.putString(key, value);
        editor.commit();
    }

    //정수 저장
    public void savePreference(String key, int value) {
        setsp();
        SharedPreferences.Editor editor = pref.edit();
        editor.putInt(key, value);
        editor.putInt("key",0);
        editor.commit();
    }

    //문자 로드
    public String loadPreference(String key, String default_value) {
        setsp();
        String str = pref.getString(key, default_value);
        return str;
    }

    //숫자 로드
    public int loadPreference(String key, int default_value) {
        setsp();
        int str = pref.getInt(key, default_value);
        return str;
    }

    public void removePreference(String key) {
        setsp();
        SharedPreferences.Editor editor = pref.edit();
        editor.remove(key);
        editor.commit();
    }

    public void setsp() {
        if(pref != null) {
            pref = null;
        }
        pref = this.activity.getSharedPreferences("pref",Activity.MODE_PRIVATE);
    }
}
